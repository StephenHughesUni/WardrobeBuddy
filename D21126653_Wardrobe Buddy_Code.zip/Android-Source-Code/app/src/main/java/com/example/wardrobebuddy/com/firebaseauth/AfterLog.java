package com.example.wardrobebuddy.com.firebaseauth;

public class AfterLog {
    // Stages of what needs to be done after login
}
