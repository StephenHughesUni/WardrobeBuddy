from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time

def scrape_hm(url):
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-gpu")
    options.add_argument("--incognito")
    options.add_argument("--disable-infobars")
    options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=options)
    driver.get(url)

    product_info = {}

    try:
        # Handle cookies if necessary
        cookies_button = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.ID, "onetrust-reject-all-handler")))
        cookies_button.click()
        print("Rejected optional cookies")

        # Wait for the product link to be present
        product_link = WebDriverWait(driver, 4).until(EC.presence_of_element_located((By.CSS_SELECTOR, ".item-link")))

        # Execute JavaScript to click the product link
        driver.execute_script("arguments[0].click();", product_link)
        print("Clicked on product link")


        # Pause for 3 seconds to allow page to load
        time.sleep(1)

        # Now let's extract the image URL
        item_soup = BeautifulSoup(driver.page_source, 'html.parser')
        item_image = item_soup.find('img', class_='product-detail-thumbnail-image')
        if item_image:
            image_url = item_image['src']
            # Ensure the URL is complete
            if not image_url.startswith("http"):
                image_url = "https:" + image_url
            product_info['image_url'] = image_url
            print("Item image URL:", image_url)
        else:
            print("Item image not found")

        # Check if "Size not available online" message is present
        size_not_available_message = driver.find_elements(By.XPATH, "//div[contains(text(), 'Size not available online')]")
        if size_not_available_message:
            print("Size not available online")
            # Directly assign "Size not available online" to the result
            product_info['location_info'] = [{"area": "Size not available online", "title": "", "message": ""}]
        else:
            # Find the container that holds size information
            size_list_container = item_soup.find('ul', class_='ListGrid-module--listGrid__3gCNA')

            size_availability = {}
            if size_list_container:
                # Extract all the sizes listed
                sizes = size_list_container.find_all('label')
                for size in sizes:
                    size_label = size.text.strip().replace("Few pieces left", "").strip()  # Remove "Few pieces left" indication
                    input_element = size.find('input', {'type': 'radio'})  # Find the input element
                    is_available = not input_element.has_attr('disabled')  # Check if input element is disabled
                    size_availability[size_label] = is_available

            # Print the size availability
            print("Size Availability:")
            for size, availability in size_availability.items():
                print(f"Size: {size}, Available: {availability}")

            product_info['size_availability'] = size_availability

            # Before attempting to click the "Find in store" button, check if the item is not available in stores
            not_available_in_stores = driver.find_elements(By.CSS_SELECTOR, "button.ProductStoreLocator-module--disabled__WHFIN")
            if not_available_in_stores:
                print("Item not available in stores")
                # Directly assign "Not available in stores" to the 'area' and leave other fields empty
                product_info['location_info'] = [{"area": "Not available in stores", "title": "", "message": ""}]
            else:
                # The button may need to be made visible first by scrolling into view
                find_in_store_button = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "hm-find-in-store button.CTA-module--action__1qN9s")))
                driver.execute_script("arguments[0].scrollIntoView();", find_in_store_button)
                find_in_store_button.click()
                print("Clicked 'Find in store' button")

                # Wait for the location input field to be clickable
                location_input = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "addressAutocomplete")))

                # Enter location "Drimnagh, Dublin, D12 PX80" into the input field
                location_input.send_keys("Drimnagh, Dublin, D12 PX80")
                print("Entered location")
                
                time.sleep(3)
                
                # Press Enter
                location_input.send_keys(Keys.ENTER)
                print("Pressed Enter")

                # Pause for 5 seconds to allow the search results to load
                time.sleep(3)

                # Parse and list the store search results after finding in-store availability
                soup = BeautifulSoup(driver.page_source, 'html.parser')
                stores = soup.select('.StoreToggle-module--topContent__1Q-E4')
                print("\nLocation Search Results:")
                location_info = []
                for store in stores:
                    area = store.select_one('.StoreToggle-module--heading__1xECI').text.strip()
                    title = store.select_one('address').text.strip().replace("\n", ", ")
                    sizes_container = store.select_one('.ProductSizes-module--sizeContainer__2EWC0')
                    available_sizes = []
                    if sizes_container:
                        sizes = sizes_container.find_all('li', class_='ProductSizes-module--size__2FGc2')
                        for size in sizes:
                            size_label = size.text.strip()
                            icon = size.find('svg')
                            if icon and "fill=\"#00853d\"" in str(icon):  # Check for green tick icon for available sizes
                                available_sizes.append(size_label)
                    message = "Available Sizes: " + ", ".join(available_sizes)
                    print(f"Area: {area}, Title: {title}, Message: {message}")
                    location_info.append({"area": area, "title": title, "message": message})

                product_info['location_info'] = location_info

    finally:
        # Close the WebDriver session
        driver.quit()

    return product_info

# Call the function with the URL
url = "https://www2.hm.com/en_ie/search-results.html?q=1226566003"
result = scrape_hm(url)
print(result)
