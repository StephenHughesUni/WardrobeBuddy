from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def scrape_cos(url):
    
    
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-gpu")
    options.add_argument("--incognito")
    options.add_argument("--disable-infobars")
    options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=options)
    driver.get(url)

    product_info = {}
    
    try:
            # Handle cookies if present
            WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "onetrust-reject-all-handler"))).click()
            print("Handled cookie consent")

            # Extract product link
            product_link_element = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, ".o-product .image-if-hover a"))
            )
            product_link = product_link_element.get_attribute('href')
            print(f"Product Link: {product_link}")
            product_link_element.click()
            print("Clicked on product link")

            # Allow some time for the product page to load
            time.sleep(1)

            # Assuming you are now on the product detail page and the image URL is loaded
            # Here you should extract the HTML of the page
            # For example, let's assume you extracted it and loaded into BeautifulSoup
            page_html = driver.page_source
            soup = BeautifulSoup(page_html, 'html.parser')

            # Find the <img> tag within the <picture> element
            img_tag = soup.find('picture', class_='a-picture').find('img')
            if img_tag and 'data-zoom-src' in img_tag.attrs:
                image_url = img_tag['data-zoom-src']
                # Ensure the URL is complete
                if not image_url.startswith("http"):
                    image_url = "https:" + image_url
                product_info['image_url'] = image_url
                print("Item image URL:", image_url)
            else:
                print("Item image not found")

            # Find the size container
            size_container = soup.find('div', class_='size-select')

            size_availability = {}
            if size_container:
                size_items = size_container.find_all('button', class_='size-options')
                for item in size_items:
                    size_label = item.text.strip()
                    is_available = not item.has_attr('disabled')
                    size_availability[size_label] = is_available

            product_info['size_availability'] = size_availability
            product_info['product_link'] = product_link

            print("Size Availability:")
            for size, availability in size_availability.items():
                print(f"Size: {size}, Available: {availability}")

            # Click the "Find In Store" button
            find_in_store_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, ".m-brands-find-in-store__findInStoreButton"))
            )
            find_in_store_button.click()
            print("Clicked on Find In Store button")

            # Allow some time for the Find In Store page to load
            time.sleep(1)
            
            # Define sizes
            sizes = ['XS', 'S', 'M', 'L', 'XL']
            
            location_availability = {}


            # Iterate over each size
            for size in sizes:
                # Select size
                select_size_dropdown = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, ".Select-module--select__14U3U"))
                )
                select_size_dropdown.click()
                print(f"Clicked on Select size dropdown for size {size}")
                time.sleep(1)
                
                option_value = {
                    'XS': '001',
                    'S': '002',
                    'M': '003',
                    'L': '004',
                    'XL': '005'
                }

                option = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, f"option[value='{option_value[size]}']"))
                )
                option.click()
                print(f"Selected size {size}")
                time.sleep(1)

                # After selecting the size and loading the availability, parse the locations
                soup = BeautifulSoup(driver.page_source, 'html.parser')
                locations = soup.select('.Store-module--listElement__3ztMo')

                for location in locations:
                    area = location.select_one('address > span:nth-of-type(1)').text.strip()
                    title = location.select_one('address > span:nth-of-type(2)').text.strip()
                    availability = location.select_one('.ProductSizes-module--size__2FGc2').text.strip()

                    # Initialize the location in the dictionary if it's the first time we're seeing it
                    if title not in location_availability:
                        location_availability[title] = {"area": area, "title": title, "sizes": {}}
                    
                    # Update the size availability for the current location
                    location_availability[title]["sizes"][size] = availability

            # After collecting all data, prepare the final output format
            final_location_info = []
            for location in location_availability.values():
                # Initialize lists to keep track of messages for available sizes and those with limited stock
                in_stock_sizes = []
                last_few_left_sizes = []
                
                for size, status in location["sizes"].items():
                    if "In stock" in status:
                        in_stock_sizes.append(size)
                    elif "Last few left" in status:
                        last_few_left_sizes.append(size)

                # Format the message based on stock availability
                messages = []
                if in_stock_sizes:
                    messages.append(f"In stock: {', '.join(in_stock_sizes)}")
                if last_few_left_sizes:
                    messages.append(f"Last few left: {', '.join(last_few_left_sizes)}")
                message = "; ".join(messages) if messages else "Sold out"

                final_location_info.append({
                    "area": location["area"],
                    "title": location["title"],
                    "message": message
                })

            product_info['location_info'] = final_location_info
            
            print(final_location_info)

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # Close the WebDriver session
        driver.quit()

    return product_info

# Call the function with the URL
url = "https://www.cos.com/en_eur/search.html?q=1148844015"
result = scrape_cos(url)
print(result)
