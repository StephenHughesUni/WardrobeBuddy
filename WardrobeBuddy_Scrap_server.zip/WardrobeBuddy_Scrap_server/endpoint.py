from fastapi import FastAPI, Query
from selenium_script import fetch_product_info

app = FastAPI()

@app.get("/fetch-product-info/")
async def fetch_product_info_endpoint(product_url: str = Query(...), brand: str = Query(...)):
    product_info = fetch_product_info(product_url, brand)
    return {"product_info": product_info}
