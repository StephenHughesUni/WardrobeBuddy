from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from fastapi import FastAPI, Query
import time

app = FastAPI()

def scrape_hm(url):
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-gpu")
    options.add_argument("--incognito")
    options.add_argument("--disable-infobars")
    options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=options)
    driver.get(url)

    product_info = {}

    try:
        # Handle cookies if necessary
        cookies_button = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.ID, "onetrust-reject-all-handler")))
        cookies_button.click()
        print("Rejected optional cookies")

        # Wait for the product link to be present
        product_link = WebDriverWait(driver, 4).until(EC.presence_of_element_located((By.CSS_SELECTOR, ".item-link")))

        # Execute JavaScript to click the product link
        driver.execute_script("arguments[0].click();", product_link)
        print("Clicked on product link")


        # Pause for 3 seconds to allow page to load
        time.sleep(1)

        # Now let's extract the image URL
        item_soup = BeautifulSoup(driver.page_source, 'html.parser')
        item_image = item_soup.find('img', class_='product-detail-thumbnail-image')
        if item_image:
            image_url = item_image['src']
            # Ensure the URL is complete
            if not image_url.startswith("http"):
                image_url = "https:" + image_url
            product_info['image_url'] = image_url
            print("Item image URL:", image_url)
        else:
            print("Item image not found")

        # Check if "Size not available online" message is present
        size_not_available_message = driver.find_elements(By.XPATH, "//div[contains(text(), 'Size not available online')]")
        if size_not_available_message:
            print("Size not available online")
            # Directly assign "Size not available online" to the result
            product_info['location_info'] = [{"area": "Size not available online", "title": "", "message": ""}]
        else:
            # Find the container that holds size information
            size_list_container = item_soup.find('ul', class_='ListGrid-module--listGrid__3gCNA')

            size_availability = {}
            if size_list_container:
                # Extract all the sizes listed
                sizes = size_list_container.find_all('label')
                for size in sizes:
                    size_label = size.text.strip().replace("Few pieces left", "").strip()  # Remove "Few pieces left" indication
                    input_element = size.find('input', {'type': 'radio'})  # Find the input element
                    is_available = not input_element.has_attr('disabled')  # Check if input element is disabled
                    size_availability[size_label] = is_available

            # Print the size availability
            print("Size Availability:")
            for size, availability in size_availability.items():
                print(f"Size: {size}, Available: {availability}")

            product_info['size_availability'] = size_availability

            # Before attempting to click the "Find in store" button, check if the item is not available in stores
            not_available_in_stores = driver.find_elements(By.CSS_SELECTOR, "button.ProductStoreLocator-module--disabled__WHFIN")
            if not_available_in_stores:
                print("Item not available in stores")
                # Directly assign "Not available in stores" to the 'area' and leave other fields empty
                product_info['location_info'] = [{"area": "Not available in stores", "title": "", "message": ""}]
            else:
                # The button may need to be made visible first by scrolling into view
                find_in_store_button = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "hm-find-in-store button.CTA-module--action__1qN9s")))
                driver.execute_script("arguments[0].scrollIntoView();", find_in_store_button)
                find_in_store_button.click()
                print("Clicked 'Find in store' button")

                # Wait for the location input field to be clickable
                location_input = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "addressAutocomplete")))

                # Enter location "Drimnagh, Dublin, D12 PX80" into the input field
                location_input.send_keys("Drimnagh, Dublin, D12 PX80")
                print("Entered location")
                
                time.sleep(3)
                
                # Press Enter
                location_input.send_keys(Keys.ENTER)
                print("Pressed Enter")

                # Pause for 5 seconds to allow the search results to load
                time.sleep(3)

                # Parse and list the store search results after finding in-store availability
                soup = BeautifulSoup(driver.page_source, 'html.parser')
                stores = soup.select('.StoreToggle-module--topContent__1Q-E4')
                print("\nLocation Search Results:")
                location_info = []
                for store in stores:
                    area = store.select_one('.StoreToggle-module--heading__1xECI').text.strip()
                    title = store.select_one('address').text.strip().replace("\n", ", ")
                    sizes_container = store.select_one('.ProductSizes-module--sizeContainer__2EWC0')
                    available_sizes = []
                    if sizes_container:
                        sizes = sizes_container.find_all('li', class_='ProductSizes-module--size__2FGc2')
                        for size in sizes:
                            size_label = size.text.strip()
                            icon = size.find('svg')
                            if icon and "fill=\"#00853d\"" in str(icon):  # Check for green tick icon for available sizes
                                available_sizes.append(size_label)
                    message = "Available Sizes: " + ", ".join(available_sizes)
                    print(f"Area: {area}, Title: {title}, Message: {message}")
                    location_info.append({"area": area, "title": title, "message": message})

                product_info['location_info'] = location_info

    finally:
        # Close the WebDriver session
        driver.quit()

    return product_info


def scrape_cos(url):
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-gpu")
    options.add_argument("--incognito")
    options.add_argument("--disable-infobars")
    options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=options)
    driver.get(url)

    product_info = {}
    
    try:
            # Handle cookies if present
            WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, "onetrust-reject-all-handler"))).click()
            print("Handled cookie consent")

            # Extract product link
            product_link_element = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, ".o-product .image-if-hover a"))
            )
            product_link = product_link_element.get_attribute('href')
            print(f"Product Link: {product_link}")
            product_link_element.click()
            print("Clicked on product link")

            # Allow some time for the product page to load
            time.sleep(1)

            # Assuming you are now on the product detail page and the image URL is loaded
            # Here you should extract the HTML of the page
            # For example, let's assume you extracted it and loaded into BeautifulSoup
            page_html = driver.page_source
            soup = BeautifulSoup(page_html, 'html.parser')

            # Find the <img> tag within the <picture> element
            img_tag = soup.find('picture', class_='a-picture').find('img')
            if img_tag and 'data-zoom-src' in img_tag.attrs:
                image_url = img_tag['data-zoom-src']
                # Ensure the URL is complete
                if not image_url.startswith("http"):
                    image_url = "https:" + image_url
                product_info['image_url'] = image_url
                print("Item image URL:", image_url)
            else:
                print("Item image not found")

            # Find the size container
            size_container = soup.find('div', class_='size-select')

            size_availability = {}
            if size_container:
                size_items = size_container.find_all('button', class_='size-options')
                for item in size_items:
                    size_label = item.text.strip()
                    is_available = not item.has_attr('disabled')
                    size_availability[size_label] = is_available

            product_info['size_availability'] = size_availability
            product_info['product_link'] = product_link

            print("Size Availability:")
            for size, availability in size_availability.items():
                print(f"Size: {size}, Available: {availability}")

            # Click the "Find In Store" button
            find_in_store_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, ".m-brands-find-in-store__findInStoreButton"))
            )
            find_in_store_button.click()
            print("Clicked on Find In Store button")

            # Allow some time for the Find In Store page to load
            time.sleep(1)
            
            # Define sizes
            sizes = ['XS', 'S', 'M', 'L', 'XL']
            
            location_availability = {}


            # Iterate over each size
            for size in sizes:
                # Select size
                select_size_dropdown = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, ".Select-module--select__14U3U"))
                )
                select_size_dropdown.click()
                print(f"Clicked on Select size dropdown for size {size}")
                time.sleep(1)
                
                option_value = {
                    'XS': '001',
                    'S': '002',
                    'M': '003',
                    'L': '004',
                    'XL': '005'
                }

                option = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, f"option[value='{option_value[size]}']"))
                )
                option.click()
                print(f"Selected size {size}")
                time.sleep(1)

                # After selecting the size and loading the availability, parse the locations
                soup = BeautifulSoup(driver.page_source, 'html.parser')
                locations = soup.select('.Store-module--listElement__3ztMo')

                for location in locations:
                    area = location.select_one('address > span:nth-of-type(1)').text.strip()
                    title = location.select_one('address > span:nth-of-type(2)').text.strip()
                    availability = location.select_one('.ProductSizes-module--size__2FGc2').text.strip()

                    # Initialize the location in the dictionary if it's the first time we're seeing it
                    if title not in location_availability:
                        location_availability[title] = {"area": area, "title": title, "sizes": {}}
                    
                    # Update the size availability for the current location
                    location_availability[title]["sizes"][size] = availability

            # After collecting all data, prepare the final output format
            final_location_info = []
            for location in location_availability.values():
                # Initialize lists to keep track of messages for available sizes and those with limited stock
                in_stock_sizes = []
                last_few_left_sizes = []
                
                for size, status in location["sizes"].items():
                    if "In stock" in status:
                        in_stock_sizes.append(size)
                    elif "Last few left" in status:
                        last_few_left_sizes.append(size)

                # Format the message based on stock availability
                messages = []
                if in_stock_sizes:
                    messages.append(f"In stock: {', '.join(in_stock_sizes)}")
                if last_few_left_sizes:
                    messages.append(f"Last few left: {', '.join(last_few_left_sizes)}")
                message = "; ".join(messages) if messages else "Sold out"

                final_location_info.append({
                    "area": location["area"],
                    "title": location["title"],
                    "message": message
                })

            product_info['location_info'] = final_location_info
            
            print(final_location_info)

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # Close the WebDriver session
        driver.quit()

    return product_info

def scrape_zara(url):
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-gpu")
    options.add_argument("--incognito")
    options.add_argument("--disable-infobars")
    options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=options)
    driver.get(url)

    product_info = {}

    try:
        # Reject optional cookies
        cookies_button = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.ID, "onetrust-reject-all-handler")))
        cookies_button.click()
        print("Rejected optional cookies")

        # Extract product link
        product_link = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CLASS_NAME, "product-link")))
        href = product_link.get_attribute("href")
        print("Full link to the item:", href)

        # Extract size availability from the item page
        driver.get(href)
        item_soup = BeautifulSoup(driver.page_source, 'html.parser')
        
        # Grab the item image URL
        item_image = item_soup.find('img', class_='media-image__image')
        if item_image:
            image_url = item_image['src']
            product_info['image_url'] = image_url
            print("Item image URL:", image_url)
        else:
            print("Item image not found")

        time.sleep(3)
        # Find all size list items
        size_items = item_soup.find_all('li', class_='size-selector-list__item')

        # Dictionary to store size availability
        size_availability = {}

        # Iterate through each size item
        for item in size_items:
            size_label = item.find('div', class_='product-size-info__main-label').text.strip()
            is_available = not item.has_attr('class') or 'size-selector-list__item--out-of-stock' not in item['class']
            size_availability[size_label] = is_available

        product_info['size_availability'] = size_availability

        # Click the "Check in-store availability" button
        in_store_availability_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[data-qa-action='store-stock']")))
        driver.execute_script("arguments[0].scrollIntoView();", in_store_availability_button)
        driver.execute_script("arguments[0].click();", in_store_availability_button)
        print("Clicked 'Check in-store availability' button")

        time.sleep(3)
        # Choose sizes dynamically by selecting all checkboxes with names starting with "size_"
        size_script = """
        var checkboxes = document.querySelectorAll("input[name^='size_']");
        checkboxes.forEach(function(checkbox) {
            checkbox.click();
        });
        """
        driver.execute_script(size_script)

        time.sleep(3)
        # Click the "CHECK AVAILABILITY" button
        check_availability_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".product-stock-availability-size-selector-form__button")))
        check_availability_button.click()
        print("Clicked 'CHECK AVAILABILITY' button")

        time.sleep(3)
        # Enter location (e.g., "DUBLIN") into the input field
        location_input = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".zds-input-base__input[name='search']")))
        location_input.send_keys("DUBLIN")
        print("Entered location")

        # Click the search button
        search_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[data-qa-action='search-physical-stores']")))
        search_button.click()
        print("Clicked 'Search' button")

        # Pause for a moment to allow time for the location search results to load
        time.sleep(3)

        # Parse and list the location search results
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        locations = soup.select('.location-search__location')
        print("\nLocation Search Results:")
        location_info = []
        for location in locations:
            area = location.select_one('.location-search-location__area').text.strip()
            title = location.select_one('.location-search-location__title').text.strip()
            message = location.select_one('.location-search-message').text.strip()
            print(f"Area: {area}")
            print(f"Title: {title}")
            print(f"Message: {message}")
            print()  # Print an empty line for better readability
            location_info.append({"area": area, "title": title, "message": message})

        product_info['location_info'] = location_info

    except Exception as e:
        print("An error occurred:", e)

    finally:
        # Close the WebDriver session
        driver.quit()

    return product_info


def fetch_product_info(url, brand):
    if brand.lower() == 'zara':
        return scrape_zara(url)
    elif brand.lower() == 'h&m':
        return scrape_hm(url)
    elif brand.lower() == 'cos':
        return scrape_cos(url)
    else:
        # Add logic for other brands if needed
        print(f"Scraping logic for {brand} is not implemented yet.")
        return None
    
@app.get("/fetch-product-info/")
async def fetch_product_info_endpoint(product_url: str = Query(...), brand: str = Query(...)):
    product_info = fetch_product_info(product_url, brand)
    return {"product_info": product_info}
    
    

