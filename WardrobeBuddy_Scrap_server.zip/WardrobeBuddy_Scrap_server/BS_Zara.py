from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def scrape_zara(url):
    options = webdriver.ChromeOptions()
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-gpu")
    options.add_argument("--incognito")
    options.add_argument("--disable-infobars")
    options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(options=options)
    driver.get(url)

    product_info = {}

    try:
        # Reject optional cookies
        cookies_button = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.ID, "onetrust-reject-all-handler")))
        cookies_button.click()
        print("Rejected optional cookies")

        # Extract product link
        product_link = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CLASS_NAME, "product-link")))
        href = product_link.get_attribute("href")
        print("Full link to the item:", href)

        # Extract size availability from the item page
        driver.get(href)
        item_soup = BeautifulSoup(driver.page_source, 'html.parser')
        
        # Grab the item image URL
        item_image = item_soup.find('img', class_='media-image__image')
        if item_image:
            image_url = item_image['src']
            product_info['image_url'] = image_url
            print("Item image URL:", image_url)
        else:
            print("Item image not found")

        time.sleep(3)
        # Find all size list items
        size_items = item_soup.find_all('li', class_='size-selector-list__item')

        # Dictionary to store size availability
        size_availability = {}

        # Iterate through each size item
        for item in size_items:
            size_label = item.find('div', class_='product-size-info__main-label').text.strip()
            is_available = not item.has_attr('class') or 'size-selector-list__item--out-of-stock' not in item['class']
            size_availability[size_label] = is_available

        product_info['size_availability'] = size_availability

        # Click the "Check in-store availability" button
        in_store_availability_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[data-qa-action='store-stock']")))
        driver.execute_script("arguments[0].scrollIntoView();", in_store_availability_button)
        driver.execute_script("arguments[0].click();", in_store_availability_button)
        print("Clicked 'Check in-store availability' button")

        time.sleep(3)
        # Choose sizes dynamically by selecting all checkboxes with names starting with "size_"
        size_script = """
        var checkboxes = document.querySelectorAll("input[name^='size_']");
        checkboxes.forEach(function(checkbox) {
            checkbox.click();
        });
        """
        driver.execute_script(size_script)

        time.sleep(3)
        # Click the "CHECK AVAILABILITY" button
        check_availability_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".product-stock-availability-size-selector-form__button")))
        check_availability_button.click()
        print("Clicked 'CHECK AVAILABILITY' button")

        time.sleep(3)
        # Enter location (e.g., "DUBLIN") into the input field
        location_input = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".zds-input-base__input[name='search']")))
        location_input.send_keys("DUBLIN")
        print("Entered location")

        # Click the search button
        search_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "[data-qa-action='search-physical-stores']")))
        search_button.click()
        print("Clicked 'Search' button")

        # Pause for a moment to allow time for the location search results to load
        time.sleep(3)

        # Parse and list the location search results
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        locations = soup.select('.location-search__location')
        print("\nLocation Search Results:")
        location_info = []
        for location in locations:
            area = location.select_one('.location-search-location__area').text.strip()
            title = location.select_one('.location-search-location__title').text.strip()
            message = location.select_one('.location-search-message').text.strip()
            print(f"Area: {area}")
            print(f"Title: {title}")
            print(f"Message: {message}")
            print()  # Print an empty line for better readability
            location_info.append({"area": area, "title": title, "message": message})

        product_info['location_info'] = location_info

    except Exception as e:
        print("An error occurred:", e)

    finally:
        # Close the WebDriver session
        driver.quit()

    return product_info

# Call the function with the URL
url = "https://www.zara.com/ie/en/search?searchTerm=2810%2F633%2F303&section=WOMAN"
result = scrape_zara(url)
print(result)
